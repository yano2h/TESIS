/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.hslu.d3s;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import org.openid4java.OpenIDException;
import org.openid4java.consumer.ConsumerException;
import org.openid4java.consumer.ConsumerManager;
import org.openid4java.consumer.VerificationResult;
import org.openid4java.discovery.DiscoveryException;
import org.openid4java.discovery.DiscoveryInformation;
import org.openid4java.discovery.Identifier;
import org.openid4java.message.AuthRequest;
import org.openid4java.message.AuthSuccess;
import org.openid4java.message.MessageException;
import org.openid4java.message.ParameterList;
import org.openid4java.message.ax.AxMessage;
import org.openid4java.message.ax.FetchRequest;
import org.openid4java.message.ax.FetchResponse;

/**
 *
 * @author Jano
 */
@ManagedBean
@SessionScoped
public class OpenIdGoogle {

    private static String ENDPONT_GOOGLE = "https://www.google.com/accounts/o8/id";
    
    private ConsumerManager manager;
    private DiscoveryInformation discovered;
    private String openIdEmail;
    private String validatedId;
            
    public OpenIdGoogle() {
    }
    
    public void loginGoogle(){
        try {
            manager = new ConsumerManager();
            String returnToUrl = returnToUrl("/openid_1.xhtml");
            String url = authRequest(returnToUrl);
            
            if (url != null) {
                System.out.println("URL:"+url);
                FacesContext.getCurrentInstance().getExternalContext().redirect(url);
            }
        } catch (IOException ex) {
            Logger.getLogger(OpenIdGoogle.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DiscoveryException ex) {
            Logger.getLogger(OpenIdGoogle.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessageException ex) {
            Logger.getLogger(OpenIdGoogle.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ConsumerException ex) {
            Logger.getLogger(OpenIdGoogle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
     private String returnToUrl(String urlExtension) {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        String returnToUrl = "http://" + request.getServerName() + ":" + request.getServerPort()
                + context.getApplication().getViewHandler().getActionURL(context, urlExtension);
        System.out.println("return to:"+returnToUrl);
        return returnToUrl;
    }
     
    private String authRequest(String returnToUrl) throws IOException, DiscoveryException, MessageException, ConsumerException {
        try {
            List discoveries = manager.discover(ENDPONT_GOOGLE);
            discovered = manager.associate(discoveries);
            AuthRequest authReq = manager.authenticate(discovered, returnToUrl);
 
            FetchRequest fetch = FetchRequest.createFetchRequest();
            fetch.addAttribute("email","http://schema.openid.net/contact/email", true);
            authReq.addExtension(fetch);
            
            return authReq.getDestinationUrl(true);
        } catch (OpenIDException e) {
            // TODO
        }
        return null;
    }
    
    public String getOpenIdEmail() {
        return openIdEmail;
    }
 
    public String getOnLoad() {
        verify();
        return "pageLoaded";
    }
    
    public void verify() {
        ExternalContext context = javax.faces.context.FacesContext
                .getCurrentInstance().getExternalContext();
        HttpServletRequest request = (HttpServletRequest) context.getRequest();
        validatedId = verifyResponse(request);
    }
 
    /**
     * Set the class members with date from the authentication response.
     * Extract the parameters from the authentication response (which comes
     * in as a HTTP request from the OpenID provider). Verify the response,
     * examine the verification result and extract the verified identifier.
     * @param httpReq httpRequest
     * @return users identifier.
     */
    private String verifyResponse(HttpServletRequest httpReq) {
        try {
            ParameterList response =
                    new ParameterList(httpReq.getParameterMap());
 
            StringBuffer receivingURL = httpReq.getRequestURL();
            String queryString = httpReq.getQueryString();
            if (queryString != null && queryString.length() > 0) {
                receivingURL.append("?").append(httpReq.getQueryString());
            }
 
            VerificationResult verification = manager.verify(
                    receivingURL.toString(),
                    response, discovered);
 
            Identifier verified = verification.getVerifiedId();
            if (verified != null) {
                AuthSuccess authSuccess =
                        (AuthSuccess) verification.getAuthResponse();
 
                if (authSuccess.hasExtension(AxMessage.OPENID_NS_AX)) {
                    FetchResponse fetchResp = (FetchResponse) authSuccess.getExtension(AxMessage.OPENID_NS_AX);
 
                    List emails = fetchResp.getAttributeValues("email");
                    openIdEmail = (String) emails.get(0);
                     /* Some other attributes ... */
                }
                return verified.getIdentifier();
            }
        } catch (OpenIDException e) {
            // TODO
        }
        return null;
    }
}
