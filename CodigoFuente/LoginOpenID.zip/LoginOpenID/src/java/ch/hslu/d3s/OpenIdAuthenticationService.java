/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.hslu.d3s;

import java.util.List;
import org.openid4java.consumer.ConsumerException;
import org.openid4java.consumer.ConsumerManager;
import org.openid4java.consumer.InMemoryConsumerAssociationStore;
import org.openid4java.consumer.InMemoryNonceVerifier;
import org.openid4java.discovery.DiscoveryException;
import org.openid4java.discovery.DiscoveryInformation;

/**
 *
 * @author Jano
 */
public class OpenIdAuthenticationService {

    public static ConsumerManager consumerManager;

    private static ConsumerManager getConsumerManager() {
        if (consumerManager == null) {
            consumerManager = new ConsumerManager();
            consumerManager.setAssociations(new InMemoryConsumerAssociationStore());
            consumerManager.setNonceVerifier(new InMemoryNonceVerifier(10000));
        }

        return consumerManager;
    }

    @SuppressWarnings("unchecked")
    public static DiscoveryInformation performDiscoveryOnUserSuppliedIdentifier(String userSuppliedIdentifier) {
        DiscoveryInformation ret = null;
        //
        ConsumerManager cmngr = getConsumerManager();
        try {
            // Perform discover on the User-Supplied Identifier
            List<DiscoveryInformation> discoveries = cmngr.discover(userSuppliedIdentifier);
            // Pass the discoveries to the associate() method...
            ret = cmngr.associate(discoveries);

        } catch (DiscoveryException e) {
            String message = "Error occurred during discovery!";
            throw new RuntimeException(message, e);
        }
        return ret;
    }

    public static String getReturnToUrl() {
        return "http://localhost:8080/openid4java-sample-app/sample/OpenIdRegistrationSavePage?is_return=true";
    }
}
